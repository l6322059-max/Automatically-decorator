# Auto Deco — automatic Android build

This project includes the Auto Deco C++ source and a GitHub Actions workflow for building an Android 64-bit `.geode` package.

## Build it
1. Upload the **contents** of this folder to a GitHub repository (keep `.github/workflows/android.yml` in place).
2. Open the repository's **Actions** tab.
3. Choose **Build Auto Deco for Android** and press **Run workflow**, or push a commit to `main`.
4. Open the completed workflow run and download the `Auto-Deco-Android64` artifact.

The artifact is only produced if the build succeeds. This has not been compiled or tested yet. The project sets `geode` to `6.0.0` based on the version you reported; if that exact SDK version is unavailable, or the C++ source is incompatible, the build will fail and show an error in the Actions log. A successful compile is not yet verified.
